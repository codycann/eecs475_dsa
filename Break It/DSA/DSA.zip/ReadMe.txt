1) Please Seed in main function as internal seeding can result in different random values throughout operation.
2) Function descriptions written in .cpp file.
3) No variables are computed unless stated on .cpp file.
4) Main function must be implemented by user as previous knowledge of message length and other factors are unknown by developer.
5) HASH Function used was SHA 256 implemented by Oliver Gay. License for such software is included in documentation.

Developers:

Robert Chan (rjchan), Tyler King (tmanking), Gabor Nemeth (gzoltann)

EECS475
DSA Algorithm
Discussion: Friday 10:30
Team Name: Warriors of Crypto
