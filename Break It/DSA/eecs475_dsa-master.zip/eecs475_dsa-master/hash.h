#ifndef HASH_H
#define HASH_H

#include "uberzahl.h"

uberzahl sha256(uberzahl m, mediumType N);

#endif
