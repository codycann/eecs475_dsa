#ifndef __KEYGEN__
#define __KEYGEN__

#include "uberzahl.h"


void pqgGen(uberzahl & p, uberzahl & q, uberzahl & g); 
#endif /* __KEYGEN__ */
