#include <iostream>
#include <getopt.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "uberzahl.h"
#include "speckcipher.h"

using namespace std;

void PrintDebug(const char *format, ...);

bool DEBUG = false;

int main(int argc, char **argv){
	
	struct option longOpts[] = {
		{"keysize", required_argument, NULL, 's'},
		{"key", required_argument, NULL, 'k'},
		{"encrypt", required_argument, NULL, 'e'},
		{"decrypt", required_argument, NULL, 'd'},
		{"help", no_argument, NULL, 'h'}
	};

	int opt =0, index = 0;
	
	int encrypt_flag = 0, decrypt_flag = 0;

	string string_text = "";
	string string_key = "";
	int keysize;
	while((opt = getopt_long (argc, argv, "hs:e:d:k:", longOpts, &index)) != -1){
		switch(opt) {
			case 'e':
				encrypt_flag = 1;
                                PrintDebug("Encryption Enabled");
                                PrintDebug("Plaintext: %s", optarg);
				string_text = optarg;
				break;
			case 'd':
				decrypt_flag = 1;
                                PrintDebug("Decryption Enabled");
                                PrintDebug("Ciphertext: %s", optarg);
				string_text = optarg;
				break;
			case 's':
                                PrintDebug("Keysize: %s", optarg);
                                keysize = atoi(optarg);
                                break;
			case 'k':
                                PrintDebug("Key: %s", optarg);
                                string_key = optarg;
				break;
			case 'h':
				cout << "Speck  Cipher Cryptography from team 25" << endl;
				cout << "Authors:\nNathaniel Price\nBrandon Bloxsom\nJohnathan Ames" << endl;
				cout << "Usage:" << endl;
				cout << "-s or --keysize: speficies a keysize for the encryption step" << endl;
				cout << "-k or --key: speficies a key" << endl;
				cout << "-p or --plaintext: plaintext that you would like to encrypt/decrypt. Takes a requred argument" << endl;
				cout << "-e or --encrypt: enables encryption. Requires keysize and plaintext to be used" << endl;
				cout << "-d or --decrypt: enables decryption. Requires plaintext to be used" << endl;
				return 0;
				break;
			case '?':
				cout << "I didn't recognize one of your flags\n";
				break;
		}
	}

	if(encrypt_flag && decrypt_flag)
	{
		cout << "ERROR: Please choose either encrypt or decrpyt" << endl;
		return 0;
	}
		
	uberzahl text = string_text.c_str();
	uberzahl key = string_key.c_str();

	PrintDebug("%i", text.bitLength());
	int n = text.bitLength()/2;
	while (keysize % n) {
		n++;
	}
	int m = keysize/n;
	PrintDebug("n: %i", n);
	PrintDebug("m: %i", m);

	Speck *sp = new Speck(n, m, key); 

	//Make sure that encrypt and decrypt aren't both given
	if(encrypt_flag)
		cout << sp->encrypt(text) << endl;
	else if(decrypt_flag)
		cout << sp->decrypt(text) << endl;
	
	return 0;
}

void PrintDebug(const char *format, ...) {
        if (!DEBUG)
                return;

        va_list args;
        char buf[2048];

        va_start(args, format);
        vsprintf(buf, format, args);
        va_end(args);
        printf("+++ %s%s", buf, buf[strlen(buf)-1] != '\n'? "\n" : "");
}
