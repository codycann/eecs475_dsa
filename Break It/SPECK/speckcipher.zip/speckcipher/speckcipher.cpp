#include "speckcipher.h"

uberzahl Speck::ror(uberzahl in, unsigned int k)
{
	//rotates right by k bits
	return ((in << (BLOCKSIZE/2 - k)) % MOD) | (in >> k);
}

uberzahl Speck::rol(uberzahl in, unsigned int k)
{
	//rotates left by k bits
	return ((in << k) % MOD) | (in >> (BLOCKSIZE/2 - k));
}

void Speck::map(uberzahl &x, uberzahl &y)
{
	//DEBUG_OUTPUT
  //cout << "x: " << x << endl;
  //cout << "y: " << y << endl;
	uberzahl temp;
	temp = y;
	y = (ror(x, ALPHA) + y) % MOD;
	x = temp;
}

void Speck::second_map(uberzahl &x, uberzahl &y)
{
	uberzahl temp;
	temp = y;
	y = rol(x, BETA) ^ y;
	x = temp;
}

void Speck::invert_map(uberzahl &x, uberzahl &y)
{
	uberzahl temp;
	temp = x;
	x = rol(((y+MOD)-x) % MOD, ALPHA);
	y = temp;
}

void Speck::invert_second_map(uberzahl &x, uberzahl &y)
{
	uberzahl temp;
	temp = x;
	x = ror(x ^ y, BETA);
	y = temp;
}


Speck::Speck(int n, int m, uberzahl key)
{
  if (!calculate_sizes(n, m))
    return;

	if(N == 16)
	{
		ALPHA = 7;
		BETA = 2;
	}
	else
	{
		ALPHA = 8;
		BETA = 3;
	}

  BLOCKSIZE = 2*n;
  KEYSIZE = m*n;


  calculate_t(n, m);
  uberzahl one = 1;
  MOD = one << (BLOCKSIZE/2);
  expandkey(key);
  //DEBUG_OUTPUT
  //cout << "Block: " << BLOCKSIZE << endl;
  //cout << "Key: " << KEYSIZE << endl;
  //cout << "Num_rounds: " << T << endl;
}

bool Speck::expandkey(uberzahl k)
{
	//check for keysize
  vector<uberzahl> list;
  round_key = new vector<uberzahl>;
  round_key->push_back(k % MOD);
  K = k >> BLOCKSIZE/2;

  for (int i = 0; i < KEYSIZE/(BLOCKSIZE/2) - 1; i++) {
    list.push_back(K % MOD);
    K = K >> BLOCKSIZE/2;
  }
  for (int i = 0; i < T - 1; i++) {
    uberzahl l = list.at(i);
    uberzahl r = round_key->at(i);
    map(l, r);
    r = r ^ i;
    second_map(l, r);
    list.push_back(l);
    round_key->push_back(r);
  }

	return true;
}


uberzahl Speck::encrypt(uberzahl plauberzahlext)
{
	uberzahl l = plauberzahlext >> (BLOCKSIZE/2);
	uberzahl r = plauberzahlext % MOD;
	for(int i = 0; i < T; ++i)
	{
		map(l, r);
		r = r ^ round_key->at(i);
		second_map(l,r);
	}
	uberzahl ciphertext = (l << (BLOCKSIZE/2)) | r;
	return ciphertext;
}

uberzahl Speck::decrypt(uberzahl ciphertext)
{
	uberzahl l = ciphertext >> (BLOCKSIZE/2);
	uberzahl r = ciphertext % MOD;
	for(int i = T - 1; i >= 0; --i)
	{
		invert_second_map(l, r);
		r = r ^ round_key->at(i);
		invert_map(l, r);
	}
	uberzahl plaintext = (l << (BLOCKSIZE/2)) | r;
	return plaintext;
}

void Speck::calculate_t(int n, int m) {
  if (n == 16 && m == 4)
    T = 22;
  else if (n == 24 && m == 3)
    T = 22;
  else if (n == 24 && m == 4)
    T = 23;
  else if (n == 32 && m == 3)
    T = 26;
  else if (n == 32 && m == 4)
    T = 27;
  else if (n == 48 && m == 2)
    T = 28;
  else if (n == 48 && m == 3)
    T = 29;
  else if (n == 64 && m == 2)
    T = 32;
  else if (n == 64 && m == 3)
    T = 33;
  else if (n == 64 && m == 4)
    T = 34;
  else
    cout << "Error! Invalid n, m." << endl;
}

bool Speck::calculate_sizes(int n, int m) {
	switch(n)
	{
		case 16:
			N = 16;
			if(m == 4)
        M = 4;
			else
			{
				// bad m
				return false;
			}
			break;
		case 24:
			N = 24;
			if(m == 3)			M = 3;
			else if(m == 4)		M = 4;
			else
			{
				//bad m
				return false;
			}
			break;
		case 32:
			N = 32;
			if(m == 3)			M = 3;
			else if(m == 4)		M = 4;
			else
			{
				//bad m
				return false;
			}
			break;
		case 48:
			N = 48;
			if(m == 3)			M = 3;
			else if(m == 2)		M = 2;
			else
			{
				//bad m
				return false;
			}
			break;
		case 64:
			N = 64;
			if(m == 3)			M = 3;
			else if(m == 4)		M = 4;
			else if(m == 2)		M = 2;
			else
			{
				//bad m
				return false;
			}
			break;
		general:
			//bad n in
			return false;
			break;
	}
  return true;
}

//For testing purposes
/*
int main() {
  uberzahl key("14074904626401341155369551180448584754667373453244490859944217516317499064576");
  Speck *sp = new Speck(64, 4, key);
  uberzahl plaintext = "134851401336142382734221733825187114864";
  uberzahl cipher = sp->encrypt(plaintext);
  uberzahl plain = sp->decrypt(cipher);
  cout << "Plain: " << plaintext << endl;
  cout << "Cipher:" << cipher << endl;
  cout << "Decry: " << plain << endl;
  delete sp;
  return 0;
}
*/
