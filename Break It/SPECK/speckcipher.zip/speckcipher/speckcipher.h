#include <iostream>
#include "uberzahl.h"
#include <vector>

using namespace std;

class Speck {
  private:
    unsigned int N;
    unsigned int M;
    unsigned int T;
    unsigned int ALPHA;
    unsigned int BETA;
    unsigned int BLOCKSIZE;
    unsigned int KEYSIZE;
    vector<uberzahl> *round_key;
    uberzahl K;
    uberzahl MOD;

    uberzahl ror(uberzahl in, unsigned int k);
    uberzahl rol(uberzahl in, unsigned int k);
    void map(uberzahl &x, uberzahl &y);
    void second_map(uberzahl &x, uberzahl &y);
    void invert_map(uberzahl &x, uberzahl &y);
    void invert_second_map(uberzahl &x, uberzahl &y);
    bool calculate_sizes(int, int);
    void calculate_t(int, int);
    bool expandkey(uberzahl k);

  public:
    Speck(int, int, uberzahl);
    uberzahl encrypt(uberzahl plauberzahlext);
    uberzahl decrypt(uberzahl ciphertext);

};
