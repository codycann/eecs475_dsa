#include <algorithm>
#include <bitset>
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <sstream>
#include <unistd.h>
#include "uberzahl.h"

using namespace std;



//___________________________________________
//
// GLOBALS STRUCTS & VARIABLES
//___________________________________________



// USAGE: 	Struct containing possible values of each block size
// NOTES: 	ints since numbers won't be big + still uberzahl compatible

struct Param
{
	int blockSize;
	int wordSize;
	int keyWords;
	int rotA;
	int rotB;
	int roundsT;
};


// USAGE: 	Struct to store ciphertxt and plaintxt
// NOTES: 	In .go version, they rewrite cipher/plain text space
// 		Just in case we need it later, we copy and manipulate the copy instead

struct textPair
{
	uberzahl x;	// ciphertext
	uberzahl y;	// plaintext
};


Param blockParams;	// Used for all math
uberzahl *L;		// Size T + m - 2 
uberzahl *K;		// Size T



//___________________________________________
//
// HELPER FUNCTIONS
//___________________________________________



void printParams()
{
	cout << "Block Size:\t\t" << blockParams.blockSize << endl;
	cout << "Word Size:\t\t" << blockParams.wordSize << endl;
	cout << "Key Words:\t\t" << blockParams.keyWords << endl;
	cout << "A Rotation:\t\t" << blockParams.rotA << endl;
	cout << "B Rotation:\t\t" << blockParams.rotB << endl;
	cout << "Rounds T:\t\t" << blockParams.roundsT << endl;
}

// USAGE: 	Returns ith word in given key

uberzahl splitKeyWords(uberzahl key, int i)
{
	uberzahl result;
	int keyWordSize = blockParams.wordSize;
	uberzahl length = pow(2, (keyWordSize)) - 1;
	result = (key >> (keyWordSize * i)) & length;
	return result;
}


// USAGE:	This function breaks the cipher/plain text into two chunks, x and y.
// NOTES:	I'm mostly using this to validate the test vectors.

textPair splitUberzahl(uberzahl text)
{
	textPair result;
	int bitLength = blockParams.blockSize;
	result.x = (text.extract(bitLength/2, bitLength - 1) >> bitLength/2);
	result.y = text.extract(0, bitLength/2 - 1);
	return result;
}

string dec2base(const string& baseDigits, unsigned int value)
{
	unsigned int numberBase = (unsigned int)baseDigits.length();
	string result;
	while(value > 0)
	{
		result.push_back(baseDigits[value % numberBase]);
		value /= numberBase;
	}
	reverse(result.begin(), result.end());
	return result;
}

int base2dec(const std::string& baseDigits, const string& value)
{
	unsigned int numberBase = (unsigned int)baseDigits.length();
	unsigned int result = 0;
	for (size_t i = 0; i < value.length(); i++)
	{
		result *= numberBase;
		int c = baseDigits.find(value[i]);
		if (c == string::npos)
		{
			cout << "Invalid character" << endl;
		}
		result += (unsigned int)c;
	}
	return result;
}

int divide(const string& baseDigits, string& x, int len)
{
	string quotient;
	size_t length = x.length();
	for (size_t i = 0; i < length; i++)
	{
		size_t j = i + 1 + x.length() - length;
		if (x.length() < j)
		{
			break;
		}

		unsigned int value = base2dec(baseDigits, x.substr(0, j));

		quotient.push_back(baseDigits[value / len]);
		x = dec2base(baseDigits, value % len) + x.substr(j);
	}
	unsigned int remainder = base2dec(baseDigits, x);
	size_t n = quotient.find_first_not_of(baseDigits[0]);
	if (n != string::npos)
	{
		x = quotient.substr(n);
	}
	else
	{
		x.clear();
	}

	return remainder;
}


uberzahl hexToUber(string input)
{
	uberzahl results;
	string copy, temp;
	const char* hexSet = "0123456789abcdef";
	const char* decSet = "0123456789";
	copy = input;
	int remainder;
	while(!copy.empty() && !(copy.length() == 1 && copy[0] == hexSet[0]))
	{
		remainder = divide(hexSet, copy, 10);
		temp.push_back(decSet[remainder]);
	}
	reverse(temp.begin(), temp.end());
	results = uberzahl(temp.c_str());
	return results;
}


string uberToHex(uberzahl text)
{
	string copy, temp;
	const char* hexSet = "0123456789abcdef";
	const char* decSet = "0123456789";
	copy = text.convert_to_string();
	int remainder;
	while(!copy.empty() && !(copy.length() == 1 && copy[0] == decSet[0]))
	{
		remainder = divide(decSet, copy, 16);
		temp.push_back(hexSet[remainder]);
	}
	reverse(temp.begin(), temp.end());
	return temp;

//	stringstream ss;
//	ss << std::hex << atoi((text.convert_to_string()).c_str());
//	string results(ss.str());
//	return results;
}


// USAGE:	Return a key within a given bit range
uberzahl keyGen(int min, int max)
{
	usleep(900000);
	srand(time(NULL));
	uberzahl minUber, maxUber;
	minUber = min;
	maxUber = 2;
	maxUber = maxUber.exp(max);
	uberzahl keyUber;
	keyUber = random(minUber, maxUber);
	return keyUber;
}


//___________________________________________
//
// SPECK SETUP
//___________________________________________



// USAGE:	Initializes all parameters to be used in the cipher.
// 		SpeckSetup() must be called once before calling Encipher() or Decipher().
// NOTES:	All possible block size/key size combinations prepared (but not required by assignment)
// 		If we decide to, we can stick with just a hard enough block size and key size.


void SpeckSetup(int blockSize, uberzahl key)
{
	blockParams.blockSize = blockSize;
	int keySize = key.bitLength();
	blockParams.rotA = 8;
	blockParams.rotB = 3;
	
	if (blockSize == 32)
	{
		blockParams.rotA = 7;
		blockParams.rotB = 2;
		if (keySize <= 64)
		{
			keySize = 64;
			blockParams.roundsT = 22;
		}
		else
		{
			cerr << "Invalid keysize." << endl;
		}
	}
	else if (blockSize == 48)
	{
		if (keySize <= 72)
		{
			keySize = 72;
			blockParams.roundsT = 22;
		}
		else if (keySize <= 96)
		{
			keySize = 96;
			blockParams.roundsT = 23;
		}
		else
		{
			cerr << "Invalid keysize." << endl;
		}
	}
	else if (blockSize == 64)
	{
		if (keySize <= 96)
		{
			keySize = 96;
			blockParams.roundsT = 26;
		}
		else if (keySize <= 128)
		{
			keySize = 128;
			blockParams.roundsT = 27;
		}
		else
		{
			cerr << "Invalid keysize." << endl;
		}
	}
	else if (blockSize == 96)
	{
		if (keySize <= 96)
		{
			keySize = 96;
			blockParams.roundsT = 28;
		}
		else if (keySize <= 144)
		{
			keySize = 144;
			blockParams.roundsT = 29;
		}
		else
		{
			cerr << "Invalid keysize." << endl;
		}
	}
	else if (blockSize == 128)
	{
		if (keySize <= 128)
		{
			keySize = 128;
			blockParams.roundsT = 32;
		}
		else if (keySize <= 192)
		{
			keySize = 192;
			blockParams.roundsT = 33;
		}
		else if (keySize <= 256)
		{
			keySize = 256;
			blockParams.roundsT = 34;
		}
		else
		{
			cerr << "Invalid keysize." << endl;
		}
	}
	
	cout << "Actual KeyLength is " << key.bitLength() << endl;
	cout << "Cipher KeySize is " << keySize << endl;
	
	//---------------------------------
	// First initialize blockParams
	//---------------------------------
	
	blockParams.wordSize = blockSize/2;
	blockParams.keyWords = keySize/blockParams.wordSize;

	//---------------------------------
	// Initialize L and K
	//---------------------------------
	
	L = new uberzahl[blockParams.roundsT + blockParams.keyWords - 2];
	K = new uberzahl[blockParams.roundsT];

	K[0] = splitKeyWords(key, 0);
	for (int i = 0; i < (blockParams.keyWords - 1); i++)
	{
		L[i] = splitKeyWords(key, i + 1);
	}
	
	//---------------------------------
	// Complete Key Expansion
	//---------------------------------
	
	int index;
	uberzahl powmod = uberzahl(2);
	powmod = powmod.exp(blockParams.wordSize);
	for (int i = 0; i < (blockParams.roundsT - 1); i++)
	{
		index = i + blockParams.keyWords - 1;
		L[index] = 
			(K[i] + L[i].rotateRight(blockParams.rotA, 0, (blockParams.wordSize - 1))) ^ i;
		L[index] = 
			L[i + blockParams.keyWords - 1] % powmod;
		K[i + 1] = 
			(K[i].rotateLeft(blockParams.rotB, 0, (blockParams.wordSize - 1))) ^ L[i + blockParams.keyWords - 1];
	}
}



//___________________________________________
//
// ENCRYPT
//___________________________________________



string encrypt(string plaintext)
{
	uberzahl plainUber = hexToUber(plaintext); 
	textPair results = splitUberzahl(plainUber);
	uberzahl powmod = uberzahl(2);
	powmod = powmod.exp(blockParams.wordSize);
	for (int i = 0; i < blockParams.roundsT; i++)
	{
		results.x = 
			(results.x.rotateRight(blockParams.rotA, 0, (blockParams.blockSize/2 - 1)) + results.y) ^ K[i];
		results.x = results.x % powmod;
		results.y =
			(results.y.rotateLeft(blockParams.rotB, 0, (blockParams.blockSize/2 - 1))) ^ results.x;
	}
	return uberToHex(results.x) + uberToHex(results.y);
}



//___________________________________________
//
// DECRYPT
//___________________________________________



string decrypt(string ciphertext)
{
	uberzahl cipherUber = hexToUber(ciphertext);
	textPair results = splitUberzahl(cipherUber);
	uberzahl powmod = uberzahl(2);
	powmod = powmod.exp(blockParams.wordSize);
	uberzahl yorTemp;	// This is used multiple times later
	uberzahl xorTemp; 	// This is used to save weirder uberzahls in the math coming up
	for (int i = blockParams.roundsT - 1; i >= 0; i--)
	{
		yorTemp = results.y ^ results.x;
		results.y = yorTemp.rotateRight(blockParams.rotB, 0, (blockParams.blockSize/2 - 1));
		xorTemp = results.x ^ K[i];
		if (results.y > xorTemp)
		{
			xorTemp = xorTemp + powmod - results.y;
		}
		else
		{
			xorTemp = xorTemp - results.y;
		}
		xorTemp = xorTemp % powmod;
		results.x = xorTemp.rotateLeft(blockParams.rotA, 0, (blockParams.blockSize/2 - 1));
	}
	return uberToHex(results.x) + uberToHex(results.y);
}



//___________________________________________
//
// MAIN
//___________________________________________



int main(int argc, char* argv[])
{
	string input;
	bool running = true;
	cout << "Running speck.cpp ..." << endl;
	cout << "Select Mode: " << endl;
	cout << "\tTest : Use test vectors from pdf specifications " << endl;
	cout << "\tFree : Input your own keys, plaintext, and ciphertext " << endl << endl;
	cin >> input;
	
	//---------------------------------
	// TEST
	//---------------------------------
	if (input.compare("test") == 0 || input.compare("Test") == 0)
	{
		cout << "----------------------------------------------------" << endl;
		string plaintext;
		string ciphertext;
		string results;
		string keytext;
		uberzahl key;
		
		//---------------------------------
		// RUNNING TEST LOOP
		//---------------------------------
		while (running)
		{
			cout << "Select a block size to test." << endl;
			cout << "Type 'all' to test all test vector combinations. Type 'q' to quit." << endl;
			cin >> input;
			
			bool testAll = (input.compare("all") == 0);
		
			if (testAll || input.compare("32") == 0)
			{
				//---------------------------------
				// SPECK 32 / 64
				//---------------------------------
				cout << "SPECK32/64" << endl;
				plaintext = "6574694c";
				ciphertext = "a86842f2";
				keytext = "1918111009080100";
				key = hexToUber(keytext);
				SpeckSetup(32, key);
				printParams();
				cout << "Key:\t\t" << keytext << endl;
				cout << "Plaintext:\t" << plaintext << endl;
				results = encrypt(plaintext);
				cout << "Encrypted:\t" << results << endl << endl;
				cout << "Ciphertext:\t" << ciphertext << endl;
				results = decrypt(ciphertext);
				cout << "Decrypted:\t" << results << endl << endl;
				cout << "--------------------------------------------------" << endl;
			}
			if (testAll || input.compare("48") == 0)
			{
				//---------------------------------
				// SPECK 48 / 72
				//---------------------------------
				cout << "SPECK48/72" << endl;
				plaintext = "20796c6c6172";
				ciphertext = "c049a5385adc";
				keytext = "1211100a0908020100";
				key = hexToUber(keytext);
				SpeckSetup(48, key);
				printParams();
				cout << "Key:\t\t" << keytext << endl;
				cout << "Plaintext:\t" << plaintext << endl;
				results = encrypt(plaintext);
				cout << "Encrypted:\t" << results << endl << endl;
				cout << "Ciphertext:\t" << ciphertext << endl;
				results = decrypt(ciphertext);
				cout << "Decrypted:\t" << results << endl << endl;
				cout << "--------------------------------------------------" << endl;
	
				//---------------------------------
				// SPECK 48 / 96
				//---------------------------------
				cout << "SPECK48/96" << endl;
				plaintext = "6d2073696874";
				ciphertext = "735e10b6445d";
				keytext = "1a19181211100a0908020100";
				key = hexToUber(keytext);
				SpeckSetup(48, key);
				printParams();
				cout << "Key:\t\t" << keytext << endl;
				cout << "Plaintext:\t" << plaintext << endl;
				results = encrypt(plaintext);
				cout << "Encrypted:\t" << results << endl << endl;
				cout << "Ciphertext:\t" << ciphertext << endl;
				results = decrypt(ciphertext);
				cout << "Decrypted:\t" << results << endl << endl;
				cout << "--------------------------------------------------" << endl;
			}
			if (testAll || input.compare("64") == 0)
			{
				//---------------------------------
				// SPECK 64 / 96
				//---------------------------------
				cout << "SPECK64/96" << endl;
				plaintext = "74614620736e6165";
				ciphertext = "9f7952ec4175946c";
				keytext = "131211100b0a090803020100";
				key = hexToUber(keytext);
				SpeckSetup(64, key);
				printParams();
				cout << "Key:\t\t" << keytext << endl;
				cout << "Plaintext:\t" << plaintext << endl;
				results = encrypt(plaintext);
				cout << "Encrypted:\t" << results << endl << endl;
				cout << "Ciphertext:\t" << ciphertext << endl;
				results = decrypt(ciphertext);
				cout << "Decrypted:\t" << results << endl << endl;
				cout << "--------------------------------------------------" << endl;
		
				//---------------------------------
				// SPECK 64 / 128
				//---------------------------------
				cout << "SPECK64/128" << endl;
				plaintext = "3b7265747475432d";
				ciphertext = "8c6fa548454e028b";
				keytext = "1b1a1918131211100b0a090803020100";
				key = hexToUber(keytext);
				SpeckSetup(64, key);
				printParams();
				cout << "Key:\t\t" << keytext << endl;
				cout << "Plaintext:\t" << plaintext << endl;
				results = encrypt(plaintext);
				cout << "Encrypted:\t" << results << endl << endl;
				cout << "Ciphertext:\t" << ciphertext << endl;
				results = decrypt(ciphertext);
				cout << "Decrypted:\t" << results << endl << endl;
				cout << "--------------------------------------------------" << endl;
			
			}
			if (testAll || input.compare("96") == 0)
			{
				//---------------------------------
				// SPECK 96 / 96
				//---------------------------------
				cout << "SPECK96/96" << endl;
				plaintext = "65776f68202c656761737520";
				ciphertext = "9e4d09ab717862bdde8f79aa";
				keytext = "0d0c0b0a0908050403020100";
				key = hexToUber(keytext);
				SpeckSetup(96, key);
				printParams();
				cout << "Key:\t\t" << keytext << endl;
				cout << "Plaintext:\t" << plaintext << endl;
				results = encrypt(plaintext);
				cout << "Encrypted:\t" << results << endl << endl;
				cout << "Ciphertext:\t" << ciphertext << endl;
				results = decrypt(ciphertext);
				cout << "Decrypted:\t" << results << endl << endl;
				cout << "--------------------------------------------------" << endl;
		
				//---------------------------------
				// SPECK 96 / 144
				//---------------------------------
				cout << "SPECK96/144" << endl;
				plaintext = "656d6974206e69202c726576";
				ciphertext = "2bf31072228a7ae440252ee6";
				keytext = "1514131211100d0c0b0a0908050403020100";
				key = hexToUber(keytext);
				SpeckSetup(96, key);
				printParams();
				cout << "Key:\t\t" << keytext << endl;
				cout << "Plaintext:\t" << plaintext << endl;
				results = encrypt(plaintext);
				cout << "Encrypted:\t" << results << endl << endl;
				cout << "Ciphertext:\t" << ciphertext << endl;
				results = decrypt(ciphertext);
				cout << "Decrypted:\t" << results << endl << endl;
				cout << "--------------------------------------------------" << endl;
			}
			if (testAll || input.compare("128") == 0)
			{
				//---------------------------------
				// SPECK 128 / 128
				//---------------------------------
				cout << "SPECK128/128" << endl;
				plaintext = "6c617669757165207469206564616d20";
				ciphertext = "a65d9851797832657860fedf5c570d18";
				keytext = "0f0e0d0c0b0a09080706050403020100";
				key = hexToUber(keytext);
				SpeckSetup(128, key);
				printParams();
				cout << "Key:\t\t" << keytext << endl;
				cout << "Plaintext:\t" << plaintext << endl;
				results = encrypt(plaintext);
				cout << "Encrypted:\t" << results << endl << endl;
				cout << "Ciphertext:\t" << ciphertext << endl;
				results = decrypt(ciphertext);
				cout << "Decrypted:\t" << results << endl << endl;
				cout << "--------------------------------------------------" << endl;
		
				//---------------------------------
				// SPECK 128 / 192
				//---------------------------------
				cout << "SPECK128/192" << endl;
				plaintext = "726148206665696843206f7420746e65";
				ciphertext = "1be4cf3a13135566f9bc185de03c1886";
				keytext = "17161514131211100f0e0d0c0b0a09080706050403020100";
				key = hexToUber(keytext);
				SpeckSetup(128, key);
				printParams();
				cout << "Key:\t\t" << keytext << endl;
				cout << "Plaintext:\t" << plaintext << endl;
				results = encrypt(plaintext);
				cout << "Encrypted:\t" << results << endl << endl;
				cout << "Ciphertext:\t" << ciphertext << endl;
				results = decrypt(ciphertext);
				cout << "Decrypted:\t" << results << endl << endl;
				cout << "--------------------------------------------------" << endl;
		
				//---------------------------------
				// SPECK 128 / 256
				//---------------------------------
				cout << "SPECK128/256" << endl;
				plaintext = "65736f6874206e49202e72656e6f6f70";
				ciphertext = "4109010405c0f53e4eeeb48d9c188f43";
				keytext = "1f1e1d1c1b1a191817161514131211100f0e0d0c0b0a09080706050403020100";
				key = hexToUber(keytext);
				SpeckSetup(128, key);
				printParams();
				cout << "Key:\t\t" << keytext << endl;
				cout << "Plaintext:\t" << plaintext << endl;
				results = encrypt(plaintext);
				cout << "Encrypted:\t" << results << endl << endl;
				cout << "Ciphertext:\t" << ciphertext << endl;
				results = decrypt(ciphertext);
				cout << "Decrypted:\t" << results << endl << endl;
				cout << "--------------------------------------------------" << endl;	
			}
			
			if (input.compare("quit") == 0 || input.compare("q") == 0)
			{
				running = false;
				cout << "Exiting program..." << endl;
			}

			if (input.compare("time") == 0)
			{
				int numTrials;
				cout << "Number of trials: ";
				cin >> input;
				numTrials = atoi(input.c_str());
				cout << "Block Size: ";
				cin >> input;
				int blockSize = atoi(input.c_str());
				uberzahl key;
				int max;
				if (blockSize == 96)
				{
					max = 144;
				}
				else
				{
					max = 2 * blockSize;
				}
				

				clock_t start, end;
				float average = 0;
				string plaintext = "3b7265747475432d";
				string ciphertext = "8c6fa548454e028b";
				string results;
				cout << "Plaintext: " << plaintext << endl;
				cout << "Ciphertext: " << ciphertext << endl << endl;
				cout << "ENCRYPTION:" << endl;
				cout << "------------------------------------" << endl;
				for (int i = 0; i < numTrials; i++)
				{
					key = keyGen(1, max);
					SpeckSetup(blockSize, key);
					cout << "Key: " << uberToHex(key) << endl;
					start = clock();
					results = encrypt(plaintext);
					end = clock();
					cout << "Time taken: " << (end - start) * 1000/CLOCKS_PER_SEC;
					cout << " milliseconds." << endl << endl;;
					average += (end - start);
				}
				average = average/numTrials;
				cout << "Average time for " << numTrials << " trials: ";
				cout << average*1000/CLOCKS_PER_SEC << " milliseconds." << endl;
				cout << "------------------------------------" << endl;
			
				average = 0;
				cout << "DECRYPTION:" << endl;
				cout << "------------------------------------" << endl;
				for (int i = 0; i < numTrials; i++)
				{
					key = keyGen(1, max);
					SpeckSetup(blockSize, key);
					cout << "Key: " << uberToHex(key) << endl;
					start = clock();
					results = decrypt(ciphertext);
					end = clock();
					cout << "Time taken: " << (end - start) * 1000/CLOCKS_PER_SEC;
					cout << " milliseconds." << endl << endl;;
					average += (end - start);
				}
				average = average/numTrials;
				cout << "Average time for " << numTrials << " trials: ";
				cout << average*1000/CLOCKS_PER_SEC << " milliseconds." << endl;
				cout << "------------------------------------" << endl;
		
			
			}

		}
	}
	
	//---------------------------------
	// FREE
	//---------------------------------
	else if (input.compare("free") == 0 || input.compare("Free") == 0)
	{
		cout << "----------------------------------------------------" << endl;
		cout << "Select a block size to use for this cipher: ";
		cin >> input;
		int blockSize = atoi(input.c_str());
		while (!((blockSize == 32) || (blockSize == 48) || (blockSize == 64) || (blockSize == 96) || (blockSize == 128)))
		{
			cout << "You chose: " << blockSize << endl;
			cout << "I'm sorry, that is not a valid block size." << endl;
			cout << "Select a block size to use for this cipher: ";
			cin >> input;
			blockSize = atoi(input.c_str());
		}
		cout << "Input a key to use for this cipher, or type keygen to randomly generate a valid key: ";
		cin >> input;
		uberzahl key;
		int max;
		if (input.compare("keygen") == 0)
		{
			if (blockSize == 96)
			{
				max = 144;
			}
			else
			{
				max = 2 * blockSize;
			}
			key = keyGen(1, max);
		}
		else
		{
			key = hexToUber(input);
		}
		SpeckSetup(blockSize, key);
		cout << "Key: " << uberToHex(key) << endl;
		printParams();
		cout << "Type 'encrypt' or 'decrypt' to use the cipher. " << endl;
		cout << "Type 'reset' to change the block size and key combination. " 
		 	 << "Type 'quit' to end the program." << endl;
		textPair splitText;
		string results;
		uberzahl text;
		
		//---------------------------------
		// RUNNING FREE LOOP
		//---------------------------------
		while (running)
		{
			cin >> input;
			
			//---------------------------------
			// ENCRYPT
			//---------------------------------
			if (input.compare("encrypt") == 0 || input.compare("encr") == 0)
			{
				cout << "Plaintext: ";
				cin >> input;
				results = encrypt(input);
				cout << "Ciphertext: " << results << endl;
			}
			
			//---------------------------------
			// DECRYPT
			//---------------------------------
			else if (input.compare("decrypt") == 0 || input.compare("decr") == 0)
			{
				cout << "Ciphertext: ";
				cin >> input;
				results = decrypt(input);
				cout << "Plaintext: " << results << endl;
			}
			
			//---------------------------------
			// RESET
			//---------------------------------
			else if (input.compare("reset") == 0)
			{
				cout << "Select a block size to use for this cipher: ";
				cin >> input;
				blockSize = atoi(input.c_str());
				while (!((blockSize == 32) || (blockSize == 48) || (blockSize == 64) 
							|| (blockSize == 96) || (blockSize == 128)))
				{
					cout << "You chose: " << blockSize << endl;
					cout << "I'm sorry, that's not a valid block size." << endl;
					cout << "Select a block size to use for this cipher: ";
					cin >> input;
					blockSize = atoi(input.c_str());
				}
				cout << "Input a key to use for this cipher, or type keygen to randomly generate a valid key: ";
				cin >> input;
				if (input.compare("keygen") == 0)
				{
					if (blockSize == 96)
					{
						max = 144;
					}
					else
					{
						max = 2 * blockSize;
					}
					key = keyGen(1, max);
				}
				else
				{
					key = hexToUber(input);
				}
				SpeckSetup(blockSize, key);
				cout << "Key: " << uberToHex(key) << endl;
				printParams();
			}

			//---------------------------------
			// QUIT
			//---------------------------------
			else if (input.compare("quit") == 0 || input.compare("q") == 0)
			{
				running = false;
				cout << "Exiting program..." << endl;
			}
			else
			{
				cout << "Invalid command." << endl;
			}
		}
	}
	
	
	return 0;
}




