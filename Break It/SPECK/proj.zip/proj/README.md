eecs475FinalProject
===================
SPECK
--------------------------

Type make to compile the program and ./run to run!
To encrypt or decrypt a string, type "free" after the prompt.
(To see which test vectors we do/don't pass, type "test" instead and follow the instructions.)

In free mode:
First type the block size of the cipher you wish to encrypt with.
- Unfortunately, for some yet unknown reason, our code doesn't work with block sizes 96 and 128.
- More specifically, block size 96 can't decrypt correctly and block size 128 is just confused.
- Please grade us like we intended to code a 64 block cipher.

Next, type the key (in hex, like in the test vectors). 
- We apologize if hex is inconvenient.

Now that the cipher is set up, you have 3 options! 
- You can type "encrypt", and then a plaintext (in hex) to return an encryption.
- You can type "decrypt", and then a ciphertext (in hex) to return a decryption.
- You can also type "reset" and then repeat the process above to change the block size and key of the cipher.

At any point, you can also type "q" or "quit" to leave the program, 
but since we're all computer science majors here, ctrl+c works just as well.


Notes
------------------------------
- Our keygenerator uses the uberzahl random(a, b) function, which appears to return non-random numbers
  (specifically numbers of bitlengths between 50 and 64). 
- You can run our time trials in test mode by typing "time" instead of "all" or any block size.
