===============
| USAGE GUIDE |
===============

Compilation:
------------
Please compile maintest.cpp and speck.cpp with -std=c++11 flag


Command line usage:
-------------------
The program accepts 3 commands: keygen, encrypt, decrypt
Note that all require wordsize and key size.
There is minimal error checking, and it is expected* that you correctly
format the queries as such below:


./program keygen [wordsize] [keysize]

> Generates a key using speck::gen_key()



./program encrypt [wordsize] [keysize] [key blocks delimited by commas (hex)]
[plaintext delimited by commas (hex)]

Ex> ./program encrypt 16 64 "0x1918, 0x1110, 0x0908, 0x0100" "0x6574, 0x694c"

> Encypts "0x6574, 0x694c" using the key "0x1918, 0x1110, 0x0908, 0x0100"



./program decrypt [wordsize] [keysize] [key blocks delimited by commas (hex)]
[ciphertext delimited by commas (hex)]

Ex> ./program decrypt 16 64 "0x1918, 0x1110, 0x0908, 0x0100" "0xa868,0x42f2"

> Decrypts "0xa868,0x42f2" using key "0x1918, 0x1110, 0x0908, 0x0100"



*** Encrypt and Decrypt prints the respective ciphertext and plaintext result
	on the last line

*** Also please note that the program assumes that the ciphertext and plaintext
	inputs are of the form 2n, where the number of blocks are even. Failure to
	do so causes undefined behavior

* Causes undefined behavior for any invalid queries



Other Information:
------------------
The Speck block cipher is implemented as a class 'speck' in speck.cpp.
Further details and function descriptions on the implementation can be found
in the header file speck.h