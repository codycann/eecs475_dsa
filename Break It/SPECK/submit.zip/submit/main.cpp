#include "speck.h"
#include "test.h"

int main(int argc, char const *argv[]) {
    run_all_tests();
    run_all_timed_tests();
    return 0;
}
