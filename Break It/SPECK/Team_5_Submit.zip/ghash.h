#ifndef _GHASH_H
#define _GHASH_H

uberzahl ghash(uberzahl x, uberzahl H, int bit_length_diff);

#endif //_GHASH_H