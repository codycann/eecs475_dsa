#ifndef _MULTIPLICATION_H_
#define _MULTIPLICATION_H_

#include "uberzahl.h"

uberzahl multiply (uberzahl x, uberzahl y);

#endif //_MULTIPLICATION_H_