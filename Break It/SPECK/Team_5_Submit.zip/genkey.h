#ifndef _GENKEY_H_
#define _GENKEY_H_

void genkey();

#endif //_GENKEY_H_
