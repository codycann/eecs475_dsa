#ifndef _INCREMENT_H_
#define _INCREMENT_H_

#include "uberzahl.h"

uberzahl increment (uberzahl x);

#endif //_INCREMENT_H_