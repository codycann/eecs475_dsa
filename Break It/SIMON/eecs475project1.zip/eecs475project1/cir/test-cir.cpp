#include "cir.h"
#include <iostream>

using namespace std;

int main() {
	// initialize a number
	uint64_t a(10119);
	// bit shift it a little
	a = a << 20;
	cout << a << endl;
	for (uint8_t x = 0; x < 255; ++x)
		cout << rol(a, x) << endl; // circular shift left a by x bits
	// should see the numbers wrap around every 64 prints
}
