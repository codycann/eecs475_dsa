#!/bin/bash
g++ -o test-cir test-cir.cpp cir.cpp
