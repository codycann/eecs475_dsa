#include "cir.h"

template <typename T>
T rol(T &number, uint8_t &n) {
	return (number << n) | (number >> sizeof(T)*8 - n);
}

template <typename T>
T ror(T &number, uint8_t &n) {
	return (number >> n) | (number << sizeof(T)*8 - n);
}

uint64_t rol(uint64_t &number, uint8_t &n) {
#ifdef __amd64__
	register uint8_t cl asm("cl") = n;
	uint64_t result;
	__asm__("rol %2,%0;"
		: "=r" (result)
		: "0" (number), "r" (cl) );
	return result;
#else
	return (number << n) | (number >> sizeof(number)*8 - n);
#endif
}

uint32_t rol(uint32_t &number, uint8_t &n) {
#if defined(__i386__) || defined(__amd64__)
	register uint8_t cl asm("cl") = n;
	uint32_t result;
	__asm__("rol %2,%0;"
		: "=r" (result)
		: "0" (number), "r" (cl) );
	return result;
#else
	return (number << n) | (number >> sizeof(number)*8 - n);
#endif
}

uint64_t ror(uint64_t &number, uint8_t &n) {
#ifdef __amd64__
	register uint8_t cl asm("cl") = n;
	uint64_t result;
	__asm__("ror %2,%0;"
		: "=r" (result)
		: "0" (number), "r" (cl) );
	return result;
#else
	return (number >> n) | (number << sizeof(number)*8 - n);
#endif
}

uint32_t ror(uint32_t &number, uint8_t &n) {
#if defined(__i386__) || defined(__amd64__)
	register uint8_t cl asm("cl") = n;
	uint32_t result;
	__asm__("ror %2,%0;"
		: "=r" (result)
		: "0" (number), "r" (cl) );
	return result;
#else
	return (number >> n) | (number << sizeof(number)*8 - n);
#endif
}

