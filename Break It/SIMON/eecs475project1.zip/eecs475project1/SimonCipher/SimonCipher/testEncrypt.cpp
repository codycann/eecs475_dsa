//
//  main.cpp
//  SimonCipher
//
//  Created by Aaron Augsburger on 3/30/14.
//  Copyright (c) 2014 The Real Satoshi. All rights reserved.
//

#include "simon.h"

#include <iostream>
#include <chrono>
 
using std::chrono::duration_cast;
using std::chrono::nanoseconds;
using std::chrono::high_resolution_clock;


int main(int argc, const char * argv[])
{
	u64 wordBitlength;
	u64vec roundKeys, plainText, cipherText;
	bool executeTests = true, success = false;
	auto start = high_resolution_clock::now();
	auto end = high_resolution_clock::now();
	
		// evaluate with test suite n, m, T, and z are set within functions
	if (executeTests){

		for (int i=0; i<10; ++i) {
			testCase[i](&roundKeys, &plainText, &cipherText, &wordBitlength);
			
				// populate the remaining key values in key vector, sets T rounds
			start = high_resolution_clock::now();
			generateRoundKeys(&roundKeys, wordBitlength);
			end = high_resolution_clock::now();
			cout<<"Time to generate keys: " << 
			duration_cast<nanoseconds>(end - start).count()
			 << endl;
			
			start = high_resolution_clock::now();
			encryptText(&roundKeys, &plainText);
			end = high_resolution_clock::now();
			cout<<"Time to encrypt: " << 
			duration_cast<nanoseconds>(end - start).count()
			 << endl;			
				// check to see if plainText encrypted successfully
				// or if cipherText decrypted successfully
			success = true;
			for (int j=0; j<plainText.size(); ++j) {
				cout << "plain: " << plainText[j]<< " cipher:" << cipherText[j] << endl;
				if (plainText[j] != cipherText[j]){
					success = false;
					break;
				}
			}
			cout << "Test case " << i << ":";
			
			if (success)
				cout << " pass\n";
			else
				cout << " fail\n";
		}
	}

	return 0;
}
