// defines circular shift left (rol)
// & circular shift right (ror) functions

#include <stdint.h>

/* general cases */

// circular shift left
template <typename T> T
rol(T &number, uint8_t &n);
// circular shift right
template <typename T> T
ror(T &number, uint8_t &n);

// overloaded versions, uses inline assembly if hardware supports it

uint32_t rol(uint32_t &number, uint8_t &n); // fast on x86
uint64_t rol(uint64_t &number, uint8_t &n); // fast on x86_64

uint32_t ror(uint32_t &number, uint8_t &n); // fast on x86
uint64_t ror(uint64_t &number, uint8_t &n); // fast on x86_64

