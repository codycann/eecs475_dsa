//
//  simon.h
//  SimonCipher
//
//  Created by Aaron Augsburger on 3/30/14.
//  Copyright (c) 2014 The Real Satoshi. All rights reserved.
//

#ifndef __SimonCipher__simon__
#define __SimonCipher__simon__

#include <iostream>
#include <math.h>
#include <vector>
#include <stdint.h>

using namespace std;


#pragma mark cipher constants & basic functions

#define u8 uint8_t
#define u64 uint64_t
#define u64vec vector<u64>
typedef void(*fn)(u64vec*,u64vec*,u64vec*,u64*);

const u64 z0 = 0b11111010001001010110000111001101111101000100101011000011100110;
const u64 z1 = 0b10001110111110010011000010110101000111011111001001100001011010;
const u64 z2 = 0b10101111011100000011010010011000101000010001111110010110110011;
const u64 z3 = 0b11011011101011000110010111100000010010001010011100110100001111;
const u64 z4 = 0b11010001111001101011011000100000010111000011001010010011101111;

	// returns the nubmer of bits in a given key
u64 bitsInKey(u64 key);

	// returns the uberzahl shifted 'shift' bits
u64 bitShift(u64 num, int shift);

	// overloaded to allow specification of bits in num
u64 bitShift(u64 num, int numBits, int shift);

	// returns the value for T and z
bool setTandZ();

	// returns the nth bit of num
bool nthBit(u64 num, int n);

#pragma mark main cipher functions

	// inserts the remaining round keys in the vector
	// sets the value of T as T rounds
void generateRoundKeys(u64vec* roundKeys, u64 wordBitlength);

	// encrypts plainText with roundKeys
void encryptText(u64vec* roundKeys, u64vec* plainText);
void encryptBlock(u64vec* roundKeys, u64vec* plainText, u64 &index);

	// decrypts cipherText with roundKeys
void decryptText(u64vec* roundKeys, u64vec* cipherText);
void decryptBlock(u64vec* roundKeys, u64vec* cipherText, u64 &index);

#pragma mark test cases

	// test setups
void initSimon32_64  (u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength);
void initSimon48_72  (u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength);
void initSimon48_96  (u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength);
void initSimon64_96  (u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength);
void initSimon64_128 (u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength);
void initSimon96_96  (u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength);
void initSimon96_144 (u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength);
void initSimon128_128(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength);
void initSimon128_192(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength);
void initSimon128_256(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength);

	// test suite
const fn testCase[] = { initSimon32_64, initSimon48_72, initSimon48_96,
	initSimon64_96, initSimon64_128,initSimon96_96, initSimon96_144,
	initSimon128_128, initSimon128_192, initSimon128_256};


#endif /* defined(__SimonCipher__simon__) */
