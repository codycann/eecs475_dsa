//
//  simon.cpp
//  SimonCipher
//
//  Created by Aaron Augsburger on 3/30/14.
//  Copyright (c) 2014 The Real Satoshi. All rights reserved.
//

#include "simon.h"
#include "cir.h"
#include <algorithm>

#pragma mark basic math functions

u64 N;// caches current algorithm word size
u64 mask; //ANDing with the mask chops off extra bits (if any)
u64 m;
u64 T;
u64 z;

u64 bitsInKey(u64 key)
{
	return u64(log2(key)/1 + 1);
}

u64 rotl(u64 i, u8 shift) {
	if (N == 64)
		return rol(i, shift);
	else
		return (i << shift) | (i >> (N - shift));
}

u64 rotr(u64 i, u8 shift) {
	if (N == 64)
		return ror(i, shift);
	else
		return (i >> shift) | (i << (N - shift));
}

bool setTandZ()
{
	
	switch (N) {
		case 16:
			if (m!=4)
				return false;
			T = 32;
			z = z0;
			break;
		
		case 24:
			T = 36;
			if (m==3)
				z = z0;
			else if (m==4)
				z = z1;
			else
				return false;
			break;
			
		case 32:
			if (m==3) {
				T = 42;
				z = z2;
			}
			else if (m==4) {
				T = 44;
				z = z3;
			}
			else {
				return false;
			}
			break;
			
		case 48:
			if (m==2) {
				T = 52;
				z = z2;
			}
			else if (m==3) {
				T = 54;
				z = z3;
			}
			else {
				return false;
			}
			break;
			
		case 64:
			if (m==2){
				T = 68;
				z = z2;
			}
			else if (m==3) {
				T = 69;
				z = z3;
			}
			else if (m==4) {
				T = 72;
				z = z4;
			}
			else {
				return false;
			}
			break;
			
		default:
			cerr << "ERROR: invalid wordBitlength" << endl;
			return false;
	}
	return true;
}

u64 nthBit(u64 num, u64 n)
{
		// AND the number with a 1 in the nth bit spot, 0s otherwise
		// shift right n-bits, so the nth bit is the first one
		// will result in a 0 or 1
	u64 bitFinder(1);
	bitFinder <<= (61-n);
	bitFinder = (num & bitFinder) >> (61-n);
	if (bitFinder)
		return u64(1);
	else
		return u64(0);
}

// generates a mask that when ANDed with a number
// will chop off the extra bits greater than word size
// mask is chached as a global variable
void generateMask() {
	mask = u64(0);
	for (u64 i(0); i < N/u64(8); i++)
		mask = mask + (u64(0xff) << i*u64(8));
}

bool checkLength(u64vec* words) {
	for (int i = 0; i < words->size(); ++i) {
		if (bitsInKey((*words)[i]) > N) {
			cerr << "ERROR: Supplied word has wordBitlength > specified." << endl;
			return false;
		}
	}
	return true;
}

#pragma mark main cipher functions

void generateRoundKeys(u64vec* roundKeys, u64 wordBitlength)
{
	N = wordBitlength;
	m = u64(roundKeys->size());
	if (!checkLength(roundKeys)) {
		cerr << "Bad word in key." << endl;
		exit(EXIT_FAILURE);
	}
	if (!setTandZ()) {
		cerr << "ERROR: Invalid word bit-length or total key bit-length." << endl;
		cerr << "INFO: See SIMON/SPECK spec page 10 for vaild parameters." << endl;
		exit(EXIT_FAILURE);
	}
	generateMask(); // generate a mask for this bitlength and cache it

	// keys are/need-to-be in reverse order
	reverse(roundKeys->begin(), roundKeys->end());

	for (int i=m; i < T; i++) {
		u64 temp = rotr((*roundKeys)[i-1], 3) & mask;
		if (m == 4)
			temp ^= (*roundKeys)[i-3];
		temp = (temp ^ rotr(temp, 1)) & mask;
		temp = ~(*roundKeys)[i-m] ^ temp ^ nthBit(z, (i-m)%62) ^ u64(3);
		roundKeys->push_back(temp & mask);
	}
}
void encryptText(u64vec* roundKeys, u64vec* plainText) {
	if (!checkLength(plainText)) {
		cerr << "Bad word in plainText." << endl;
		exit(EXIT_FAILURE);
	}
	for (u64 i(0); i < u64(plainText->size()); i+=u64(2))
		encryptBlock(roundKeys, plainText, i);
}
void encryptBlock(u64vec* roundKeys, u64vec* plainText, u64 &index)
{
	u64 x = (*plainText)[index];
	u64 y = (*plainText)[index+1];
	for (int i=0; i<T; i++) {
		u64 temp = x;
		x = mask & (y ^ (rotl(x, 1) & rotl(x, 8)) ^ rotl(x, 2) ^ (*roundKeys)[i]);
		y = temp;
	}
	(*plainText)[index] = x;
	(*plainText)[index+1] = y;
}
void decryptText(u64vec* roundKeys, u64vec* cipherText) {
	if (!checkLength(cipherText)) {
		cerr << "Bad word in cipherText." << endl;
		exit(EXIT_FAILURE);
	}
	for (u64 i(0); i < u64(cipherText->size()); i+=u64(2))
		decryptBlock(roundKeys, cipherText, i);
}
void decryptBlock(u64vec* roundKeys, u64vec* cipherText, u64 &index)
{
	u64 x = (*cipherText)[index];
	u64 y = (*cipherText)[index+1];
	for (int i=T-1; i>=0; i--) {
		u64 temp = y;
		y = mask & (x ^ (rotl(y, 1) & rotl(y, 8)) ^ rotl(y, 2) ^ (*roundKeys)[i]);
		x = temp;
	}
	(*cipherText)[index] = x;
	(*cipherText)[index+1] = y;
}


#pragma mark test cases

void initSimon32_64(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength)
{
	*roundKeys  = {0x1918, 0x1110, 0x0908, 0x0100};
	*plainText  = {0x6565, 0x6877};
	*cipherText = {0xc69b, 0xe9bb};
	*wordBitlength = 16;
}

void initSimon48_72(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength)
{
	*roundKeys  = {0x121110, 0x0a0908, 0x020100};
	*plainText  = {0x612067, 0x6e696c};
	*cipherText = {0xdae5ac, 0x292cac};
	*wordBitlength = 24;
}

void initSimon48_96(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength)
{
	*roundKeys  = {0x1a1918, 0x121110, 0x0a0908, 0x020100};
	*plainText  = {0x726963, 0x20646e};
	*cipherText = {0x6e06a5, 0xacf156};
	*wordBitlength = 24;
}

void initSimon64_96(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength)
{
	*roundKeys  = {0x13121110, 0x0b0a0908, 0x03020100};
	*plainText  = {0x6f722067, 0x6e696c63};
	*cipherText = {0x5ca2e27f, 0x111a8fc8};
	*wordBitlength = 32;
}

void initSimon64_128(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength)
{
	*roundKeys  = {0x1b1a1918, 0x13121110, 0x0b0a0908, 0x03020100};
	*plainText  = {0x656b696c, 0x20646e75};
	*cipherText = {0x44c8fc20, 0xb9dfa07a};
	*wordBitlength = 32;
}

void initSimon96_96(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength)
{
	*roundKeys  = {0x0d0c0b0a0908, 0x050403020100};
	*plainText  = {0x2072616c6c69, 0x702065687420};
	*cipherText = {0x602807a462b4, 0x69063d8ff082};
	*wordBitlength = 48;
}

void initSimon96_144(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength)
{
	*roundKeys  = {0x151413121110, 0x0d0c0b0a0908, 0x050403020100};
	*plainText  = {0x746168742074, 0x73756420666f};
	*cipherText = {0xecad1c6c451e, 0x3f59c5db1ae9};
	*wordBitlength = 48;
}

void initSimon128_128(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength)
{
	*roundKeys  = {0x0f0e0d0c0b0a0908, 0x0706050403020100};
	*plainText  = {0x6373656420737265, 0x6c6c657661727420};
	*cipherText = {0x49681b1e1e54fe3f, 0x65aa832af84e0bbc};
	*wordBitlength = 64;
}

void initSimon128_192(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength)
{
	*roundKeys  = {0x1716151413121110, 0x0f0e0d0c0b0a0908, 0x0706050403020100};
	*plainText  = {0x206572656874206e, 0x6568772065626972};
	*cipherText = {0xc4ac61effcdc0d4f, 0x6c9c8d6e2597b85b};
	*wordBitlength = 64;
}

void initSimon128_256(u64vec* roundKeys, u64vec* plainText, u64vec* cipherText, u64 *wordBitlength)
{
	*roundKeys  = {0x1f1e1d1c1b1a1918, 0x1716151413121110, 0x0f0e0d0c0b0a0908, 0x0706050403020100};
	*plainText  = {0x74206e69206d6f6f, 0x6d69732061207369};
	*cipherText = {0x8d2b5579afc8a3a0, 0x3bf72a87efe7b868};
	*wordBitlength = 64;
}

