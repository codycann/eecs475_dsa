Generate Exec (Ensure you got uberzahl lib exist in the local folder):
	make
Usage:
	./simon <encrypt/decrypt> <key> <plaintext/ciphertext>
The program will return ciphertext after "encrypt", and return plaintext after "decrypt".

<encrypt/decrypt>: You have to type either "encrypt" or "decrypt".
<key>: Any key in decimal number without space. The maximal key bit length is 256 bits.
<plaintext/ciphertext>: Type any size plaintext or ciphertext here. No SAPCE and in DECIMAL number.
